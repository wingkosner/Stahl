# JS Cover Flow
A Cover Flow component made for the web. More info: http://luwes.co/labs/js-cover-flow/

## Contributors
Paul Albrecht (http://www.siteway.de/)

## Important
Licensed under [Creative Commons Attribution-NonCommercial-ShareAlike 3.0](http://creativecommons.org/licenses/by-nc-sa/3.0/)

###Known issues
False mouse click event when navigating quickly through the covers, this is caused by a bug in the Chrome browser. (http://code.google.com/p/chromium/issues/detail?id=168495)